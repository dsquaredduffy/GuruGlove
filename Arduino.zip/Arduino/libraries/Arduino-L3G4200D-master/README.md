Arduino-L3G4200D
================

L3G4200D Triple Axis Gyroscope Arduino Library.

Tutorials: http://www.jarzebski.pl/arduino/czujniki-i-sensory/3-osiowy-zyroskop-l3g4200d.html

YouTube: http://youtu.be/8llVF22r9yA

This library use I2C to communicate, 2 pins are required to interface

