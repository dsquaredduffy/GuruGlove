Arduino-KalmanFilter
====================

This library is prepared for IMU calculations

See examples: http://www.jarzebski.pl/arduino/rozwiazania-i-algorytmy/odczyty-pitch-roll-oraz-filtr-kalmana.html


